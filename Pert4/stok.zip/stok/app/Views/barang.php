<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>barang</title>
    <style>
        #barang {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #barang td,
        #barang th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #barang tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #barang tr:hover {
            background-color: #ddd;

        }

        #barang th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #DD4814;
            color: white;
        }
    </style>
</head>

<body>
    <div>
        <table id="barang">
            <tr>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Harga Barang</th>
                <th>Jumlah Barang</th>
                <th>Total Harga</th>
            </tr>
            <?php foreach ($barang as $r) : ?>
                <?php
                $TOTAL_HARGA = $r->HARGA_BRG * $r->JUMLAH_BRG
                ?>

                <tr>
                    <td><?= $r->KODE_BRG; ?></td>
                    <td><?= $r->NAMA_BRG; ?></td>
                    <td><?= $r->HARGA_BRG; ?></td>
                    <td><?= $r->JUMLAH_BRG; ?></td>
                    <td><?= $TOTAL_HARGA; ?></td>
                </tr>

            <?php endforeach ?>

        </table>
    </div>
</body>

</html>