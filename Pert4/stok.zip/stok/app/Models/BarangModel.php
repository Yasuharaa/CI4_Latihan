<?php 
namespace App\Models;

use CodeIgniter\Model;

class barangModel extends Model{
protected $table = 'barang';
protected $primaryKey = 'id';
protected $returnType = 'object';
//protected SuseSoftDeletes = true;

protected $allowedFields = ['KODE_BRG', 'NAMA_BRG', 'HARGA_BRG', 'JUMLAH_BRG'];

protected $useTimestamps = false;
// protected Screatedfield = 'created at';
// protected SupdatedField = 'updated at';
// protected $deletedField = 'deleted at'
protected $validationRules = [];
protected $validationMessages = [];
protected $skipValidation = false;
}
