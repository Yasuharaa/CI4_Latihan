<?php

namespace App\Controllers;

class Barang extends BaseController
{
    public function index()
    {
        $barangModel = new \App\Models\BarangModel();
        $barang = $barangModel->findAll();

        return view('barang', [
            'barang' => $barang,
        
        ]);
    }
}
