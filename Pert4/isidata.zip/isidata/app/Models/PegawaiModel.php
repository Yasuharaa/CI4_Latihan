<?php 
namespace App\Models;

use CodeIgniter\Model;

class PegawaiModel extends Model{
protected $table = 'pegawai';
protected $primaryKey = 'id';
protected $returnType = 'object';
//protected SuseSoftDeletes = true;

protected $allowedFields = ['nama', 'nip', 'alamat', 'telepon'];

protected $useTimestamps = false;
// protected Screatedfield = 'created at';
// protected SupdatedField = 'updated at';
// protected $deletedField = 'deleted at'
protected $validationRules = [];
protected $validationMessages = [];
protected $skipValidation = false;
}
?>