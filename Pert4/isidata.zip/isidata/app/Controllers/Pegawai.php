<?php

namespace App\Controllers;

class Pegawai extends BaseController
{
    public function index()
    {
        $pegawaiModel = new \App\Models\PegawaiModel () ;
        $pegawai = $pegawaiModel ->findAll () ;

        return view('pegawai', ['pegawai' => $pegawai]);
    }
}
