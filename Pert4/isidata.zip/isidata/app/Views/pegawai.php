<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pegawai</title>
    <style>
        #pegawai{
            font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width : 100%;
        }
        #pegawai td,
        #pegawai th{
            border : 1px solid #ddd;
            padding : 8px;
        }
        #pegawai tr:nth-child(even){
            background-color: #f2f2f2;
        }
        #pegawai tr: hover {
            background-color : #ddd;

        }
        #pegawai th{
            padding-top : 12px;
            padding-bottom : 12px;
            text-align : left;
            background-color: #DD4814;
            color: white;
        }
    </style>
</head>
<body>
    <div>
        <table id="pegawai">
            <tr>
                <th>Nama</th>
                <th>NIP</th>
                <th>Alamat</th>
                <th>Telepon</th>
            </tr>
            <?php foreach ($pegawai as $r) : ?>
                <tr>
                    <td><?= $r->nama; ?></td>
                    <td><?= $r->nip; ?></td>
                    <td><?= $r->alamat; ?></td>
                    <td><?= $r->telepon; ?></td>
                </tr>
                <?php endforeach ?>
        </table>
    </div>
</body>
</html>