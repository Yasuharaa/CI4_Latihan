<?php namespace App\Libraries;

class Widget
{

    public function recentPost()
    {
        return view('widget/recentpost');
    }
}