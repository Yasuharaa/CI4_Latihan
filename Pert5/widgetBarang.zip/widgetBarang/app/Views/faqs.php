<?= $this->extend('layout/page_layout') ?>

<?= $this->section('content') ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
        <p>Silahkan hubungi kami melalui form berikut</p>

        <p>Silahkan hubungi kami melalui form berikut</p>
        </div>
    </div>
</div>

<?= $this->endSection() ?>