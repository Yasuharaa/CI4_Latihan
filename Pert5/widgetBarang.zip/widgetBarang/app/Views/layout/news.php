<?= $this->extend('layout/post_layout') ?>

<?= $this->section('content') ?>

<h2 class="h2">Komunitas Codeigniter Indonesia Mengadakan Meetup</h2>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
<h2 class="h2">Dukungan Keamanan untuk Codeigniter 3 akan barakhir tahun ini</h2>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>

<?= $this->endSection() ?>