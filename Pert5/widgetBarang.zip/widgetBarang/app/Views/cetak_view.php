<div class="container">
    <div class="card">
        <div class="card-header bg-secondary text-white">
            <h4 class="card-title">Data Barang</h4>
        </div>
        <div class="row">
            <div class="col">
                <table class="table table-bordered table-striped table-hover">
                    <tr class="text-center">
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga Beli</th>
                        <th>Harga Jual</th>
                    </tr>
                    <?php $no =1 ?>
                    <?php foreach ($getBarang as $isi) : ?>
                        <tr>
                            <td><?= $no; ?></td>
                            <td><?= $isi['nama_barang']; ?></td>
                            <td><?= $isi['qty'] ?></td>
                            <td><?= number_format($isi['harga_beli']); ?></td>
                            <td><?= number_format($isi['harga_jual']); ?></td>
                        </tr>
                        <?php $no++; ?>
                    <?php endforeach ?>
                    
                </table>
            </div>
        </div>
    </div>

    <script>
        window.print();
    </script>