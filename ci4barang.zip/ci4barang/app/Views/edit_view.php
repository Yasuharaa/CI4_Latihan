 <div class="container pt-5">
    <a href="<?= base_url('barang'); ?>" class="btn btn-secondary mb-2">Kembali</a>
    <div class="card">
        <h4 class="card-title">Edit Barang :<?= $barang->nama_barang;?></h4>
    </div>
    <div class="card-body">
    <div class="card-body">
            <form method="post" action="<?= base_url('barang/update'); ?>">
                <div class="form-group">
                    <label for="">Nama Barang</label>
                    <input type="text" name="nama_barang" class="form-control" value="<?= $barang->nama_barang;?>" required>
                </div>
                <div class="form-group">
                    <label for="">Qty</label>
                    <input type="text" name="qty" class="form-control" value="<?= $barang->qty;?>" required>
                </div>
                <div class="form-group">
                    <label for="">Harga Beli</label>
                    <input type="text" name="harga_beli" class="form-control" value="<?= $barang->harga_beli;?>" required>
                </div>
                <div class="form-group">
                    <label for="">Harga Jual</label>
                    <input type="text" name="harga_jual" class="form-control" value="<?= $barang->harga_jual;?>" required>
                </div>
                <input type="hidden" value="<?= $barang->harga_jual;?> " name="id_barang">
                <button class="btn btn-success">Tambah Data</button>
            </form>
        </div>
    </div>
 </div>